import {styled} from '@nextui-org/react';

export const Box = styled('div', {
   boxSizing: 'border-box',
});
